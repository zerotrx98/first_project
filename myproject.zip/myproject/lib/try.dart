// GridView.builder(
// physics: NeverScrollableScrollPhysics(),
// gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
// crossAxisCount: 2,
// childAspectRatio: 1.0,
// mainAxisSpacing: 4.0,
// crossAxisSpacing: 4.0,
// ),
// itemCount: 6,
// itemBuilder: (BuildContext context, int index) {
// return GridTile(
// child: Container(
// decoration: BoxDecoration(
// color: Colors.white,
// image: DecorationImage(
// image: secondOfferImages[index]["images"])),
// ),
// );
// },
// )
// //
// //
// //
// //
// //
// //
// // Container(
// // width: double.infinity,
// // height: double.infinity,
// // child: Column(
// // children: <Widget>[
// // Expanded(
// // child: Container(
// // color: Colors.red,
// // ),
// // ),
// // Expanded(
// // child: Container(
// // color: Colors.green,
// // ),
// // ),
// // Expanded(
// // child: Container(
// // color: Colors.blue,
// // ),
// // ),
// // ],
// // ),
// // ),
