// import 'package:flutter/material.dart';
// import 'package:email_validator/email_validator.dart';
//
// class Firstpage extends StatelessWidget {
//   final formkey = GlobalKey<FormState>();
//   TextEditingController emailController = TextEditingController();
//   TextEditingController passwordController = TextEditingController();
//   late var email, password;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//
//       body: Form(
//         key: formkey,
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: TextFormField(
//                 controller: emailController,
//                 validator: (email) {
//                   if (email != null && !EmailValidator.validate(email)) {
//                     return "ENTER A EMAIL";
//                   }
//                   return null;
//                 },
//                 onSaved: (input) => email = input,
//                 decoration: InputDecoration(
//                     labelText: "EMAIL", border: OutlineInputBorder()),
//               ),
//             ),
//             SizedBox(height: 30,),
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: TextFormField(
//                 controller: passwordController,
//                 validator: (password) {
//                   if (password != null && password.length < 6) {
//                     return "enter password";
//                   }
//                   return null;
//                 },
//                 onSaved: (input) => password = input,
//                 decoration: InputDecoration(
//                     labelText: 'password', border: OutlineInputBorder()),
//               ),
//             ),
//             SizedBox(height: 30,),
//
//           ],
//         ),
//       ),
//     );
//   }
// }
