import 'package:flutter/material.dart';

class NoticiationPage extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Center(
        child: Text("Notificationpage"),
      ),
    );
  }
}