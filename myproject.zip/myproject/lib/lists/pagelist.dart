import 'package:flutter/material.dart';
import 'package:myproject/lists/dog.dart';
import 'package:myproject/lists/petlist.dart';

import 'cat.dart';
import 'fish.dart';
import '../pages/accountpage.dart';
import '../pages/cartpage.dart';
import '../pages/homepagemain.dart';
import '../pages/noticication page.dart';
import '../pages/search.dart';
import 'offerimageslist.dart';

class PagesList {
  List<Widget> pages = [
    CustomScroll(
        PetsList().details,
        PetsList().offers,
        OfferImages().offerImages,
        OfferImages().secondOfferImages,
        OfferImages().imageUrls),
    CartPage(),
    SearchPage(),
    NoticiationPage(),
    AccountPage()
  ];

 List<Widget>animalPages=[

   Dog(),
  Cat(),
   Fish(),
 ];
}
