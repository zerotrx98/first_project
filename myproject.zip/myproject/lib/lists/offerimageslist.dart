import 'dart:async';

import 'package:flutter/material.dart';

import 'dog.dart';

class OfferImages {
  List<Widget> offerImages = [
    Image.network(
        "https://d168jcr2cillca.cloudfront.net/uploadimages/sale_mainpic_20081230130245Bittoo-The-Pet-Shop.jpg"),
    Image.network(
        "https://images-eu.ssl-images-amazon.com/images/G/31/img19/Pets/DogDay/Pedigree_750x375.png"),
    Image.network(
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0nEwzLnksAlZRcvCf89XOT_xpTzQRMK6EMg&usqp=CAU"),
    Image.network(
        "https://www.marshallspetzone.com/img/magicslideshow/SUPPLEMENTS%20SLIDER%201920800.jpg"),
    Image.network(
        "https://www.marshallspetzone.com/img/magicslideshow/DROOLS%20SLIDER%201920800.jpg")
  ];
  List<Widget> secondOfferImages = [
    Image.network(
        "https://www.marshallspetzone.com/img/cms/WHISKAS%200212.jpg"),
    Image.network(
        "https://www.marshallspetzone.com/img/cms/pawzone%20dog%20shoes_1.jpg"),
    Image.network(
        "https://www.marshallspetzone.com/img/cms/DROOLS%20GRID%2014112022.jpg"),
    Image.network(
        "https://www.marshallspetzone.com/img/cms/JAN%20UPDATE/jan%20update%202/1%20(14).jpg"),
    Image.network(
        "https://www.marshallspetzone.com/img/cms/dogtoysgridnew.jpg"),
  ];
  List<dynamic> imageUrls = [
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkCFvNt8NMeobg5oxu0NvtYQy1bpXV-jY0aw&usqp=CAU",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTju-m800LVW_MIDgey6pyaichNlvn7Uscaqw&usqp=CAU",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxIw2P3t3souW-aD_8QPbaZw_xsEqlkV77Ig&usqp=CAU",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTAJXmlCp9aoNwUzSfRTNd6jy1J9-OrYIDT2g&usqp=CAU",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwdneP86fyUOmz8jLqNmuOCLq-l_fs39fnuA&usqp=CAU",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSP7k-CsNZ_n4V-PJiM8lD_Jj0vy73nSJO57g&usqp=CAU",
  ];
}

class ImageContainer extends StatefulWidget {
  final List<Widget> images;

  ImageContainer(this.images);

  @override
  _ImageContainerState createState() => _ImageContainerState();
}

class _ImageContainerState extends State<ImageContainer> {
  int _index = 0;
  int scroll = 0;

  @override
  void initState() {
    super.initState();
    Timer.periodic(Duration(seconds: 5), (timer) {
      setState(() {
        _index++;
        scroll++;
        if (_index >= widget.images.length) _index = 0;
        if (scroll >= widget.images.length) scroll = 1;
        if (_index == scroll) scroll++;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Row(
        children: [
          Container(
            width: MediaQuery.of(context).size.width * .5,
            child: widget.images[_index],
          ),
          Container(
            width: MediaQuery.of(context).size.width * .5,
            child: widget.images[scroll],
          ),
        ],
      ),
    );
  }
}
